<?php
// Direktori tempat file diupload
$target_dir = "uploads/";
$namaProduk = isset($_POST['namaProduk']) ? $_POST['namaProduk'] : '';
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

// Proses upload file
if(isset($_POST["submit"])) {
    // Cek jika file adalah gambar
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File adalah gambar - " . $check["mime"] . ".<br>";
        $uploadOk = 1;
    } else {
        echo "File bukan gambar.<br>";
        $uploadOk = 0;
    }

    // Batasan jenis file
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Maaf, hanya file JPG, JPEG, PNG, dan GIF yang diizinkan.<br>";
        $uploadOk = 0;
    }

    // Jika lolos pengecekan, simpan file
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            $data = $namaProduk . '|' . $target_file . "\n";
            file_put_contents('produk.txt', $data, FILE_APPEND);
            echo "Produk berhasil di-upload!<br>";
        } else {
            echo "Terjadi kesalahan saat upload.<br>";
        }
    }
}

// Menampilkan produk
echo "<h1>Daftar Produk</h1>";
$produkList = file('produk.txt');
foreach($produkList as $produk) {
    list($nama, $file) = explode('|', $produk);
    echo "<div><h3>$nama</h3><img src='$file' alt='$nama' style='max-width:200px;'><br></div>";
}
?>